<?php
namespace App\Controllers;

use App\Models\news\NewsModel;

class News extends BaseController {
   
    public function __construct() {
        $db = db_connect();

        $this->news                     = new NewsModel($db);
        $this->ip_address               = $_SERVER['REMOTE_ADDR'];
        $this->datetime                 = date("Y-m-d H:i:s");
    }

    public function index() {
        $this->list();
    }

    public function list() {
        $data                       = [];
        $data ['content_title']     = 'Home';
        $data ['main_content']      = 'news/list';
        $data ['result']            = $this->news->getEntryList();
        echo view('templates/template', $data);
    }

    public function add() {
        $data                       = [];
        $data ['content_title']     = 'Create News';
        $data ['main_content']      = 'news/add';
        echo view('templates/template', $data);
    }

    public function view($slug = 0) {
        $result = $this->news->getEntry(['slug' => $slug]);
        if($result) {
            $data                       = [];
            $data ['content_title']     = $result->title;
            $data ['main_content']      = 'news/view';
            $data ['result']            = $result;
            echo view('templates/template', $data);
        } else {
            return redirect()->to(base_url());
        }
    }

    public function edit() {
        $id     = $this->request->getGet('id');
        $result = $this->news->getEntry(['id' => $id]);
        if($result) {
            $data                       = [];
            $data ['content_title']     = 'Update News';
            $data ['main_content']      = 'news/edit';
            $data ['result']            = $result;
            echo view('templates/template', $data);
        } else {
            return redirect()->to(base_url());
        }
    }

    public function create() {
        $title  = $this->request->getPost('title');
        $body   = $this->request->getPost('body');
        $slug   = url_title($body, '-', true);

        $data = [
            'title'     => $title,
            'body'      => $body,
            'slug'      => $title,
        ];
        $result = $this->news->addEntry($data);
        if($result) {
            echo "News has been created successfully.";
            return redirect()->to(base_url());
        } else {
            echo "Something went wrong. Please try again.";
        }
    }

    public function update() {
        $id     = $this->request->getPost('id');
        $title  = $this->request->getPost('title');
        $body   = $this->request->getPost('body');
        $slug   = url_title($title, '-', true);

        $data = [
            'title'     => $title,
            'body'      => $body,
            'slug'      => $slug,
        ];
        $result = $this->news->updateEntry(['id' => $id], $data);
        if($result) {
            echo "News has been updated successfully.";
            return redirect()->to(base_url());
        } else {
            echo "Something went wrong. Please try again.";
        }
    }

    public function delete() {
        $id     = $this->request->getGet('id');
        $result = $this->news->deleteEntry(["id" => $id]);
        if($result) {
            echo "News has been deleted successfully.";
            return redirect()->to(base_url());
        } else {
            echo "Something went wrong. Please try again.";
        }
    }
}
