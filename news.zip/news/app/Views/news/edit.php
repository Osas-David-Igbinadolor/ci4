<form action="<?php echo base_url('news/update'); ?>" method="post">
    <input type="hidden" name="id" value="<?php echo $result->id; ?>">
    <label for="title">Title</label>
    <input type="input" name="title" placeholder="Enter title" value="<?php echo $result->title; ?>">
    <br>

    <label for="body">Text</label>
    <textarea name="body" cols="45" rows="4" placeholder="Enter body"><?php echo $result->body; ?></textarea>
    <br>

    <input type="submit" name="submit" value="Update item">

</form>