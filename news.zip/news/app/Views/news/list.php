<a href="<?php echo base_url('news/add') ?>">Add News</a>
<hr>
<?php 
foreach ($result as $key => $row) {
?>
<div>
	<h4><a href="<?php echo base_url('news/' . $row->slug) ?>"><?php echo $row->title; ?></a></h4>
	<div><?php echo $row->body; ?></div>
	<div>
		<a href="<?php echo base_url('news/edit?id=' . $row->id) ?>">Edit</a>
		<a href="<?php echo base_url('news/delete?id=' . $row->id) ?>">Delete</a>
	</div>
	<hr>
</div>
<?php
}
?>