
<div>
	<h4><?php echo $result->title; ?></h4>
	<div><?php echo $result->body; ?></div>
	<div>
		<a href="<?php echo base_url('news/edit?id=' . $result->id) ?>">Edit</a>
		<a href="<?php echo base_url('news/delete?id=' . $result->id) ?>">Delete</a>
	</div>
	<hr>
</div>