<form action="<?php echo base_url('news/create'); ?>" method="post">

    <label for="title">Title</label>
    <input type="input" name="title" placeholder="Enter title">
    <br>

    <label for="body">Text</label>
    <textarea name="body" cols="45" rows="4" placeholder="Enter body"></textarea>
    <br>

    <input type="submit" name="submit" value="Create news item">

</form>