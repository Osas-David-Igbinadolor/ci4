<?php
echo view('templates/header');
echo view($main_content);
echo view('templates/footer');